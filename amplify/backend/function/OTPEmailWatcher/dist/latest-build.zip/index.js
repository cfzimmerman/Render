const aws = require('aws-sdk')
const ses = new aws.SES()

exports.handler = async (event) => {
  for (const streamedItem of event.Records) {

    if ((streamedItem.eventName === 'MODIFY') && (streamedItem.dynamodb.NewImage.currentotp.S != streamedItem.dynamodb.OldImage.currentotp.S)) {

      // If the UserOTP table was modified to add a new 'currentotp' to a user, send that user an email of the code.
      const email = streamedItem.dynamodb.NewImage.useremail.S
      const code = streamedItem.dynamodb.NewImage.currentotp.S
      const name = streamedItem.dynamodb.NewImage.userdisplayname.S
      const originemail = 'admin@render.game'

      await ses
          .sendEmail({
            Destination: {
              ToAddresses: [email],
            },
            Source: originemail,
            Message: {
              Subject: { Data: `🗝️ Your login code is ${code}` },
              Body: { 
                Text: { Data: `Hey ${name}! Your Render login code is ${code}.` },
              },
            },
          })
          .promise()
    }
  }
  return { status: 'done' }
}